MON D.E INFAS — VERSION AVEC CACHE HORS CONNEXION

Cette archive réunit le dépôt du site et un service worker qui précharge les ressources locales du site, y compris les banques de questions, les cours et les PDF présents dans l’archive.

MISE EN LIGNE
1. Décompressez le contenu de cette archive.
2. Publiez tous les fichiers et dossiers à la racine du dépôt qui héberge le site (ne publiez pas le dossier parent).
3. Ouvrez le site une première fois avec une connexion Internet et attendez la fin du préchargement.
4. Sur Android, utilisez le menu du navigateur « Ajouter à l’écran d’accueil » si vous souhaitez l’ouvrir comme une application.
5. Après le préchargement, testez le mode avion.

À SAVOIR
- Une première connexion est indispensable pour télécharger les ressources.
- Le cache hors connexion dépend de l’espace disponible et des limites du navigateur. Le service worker tente de mettre en cache chaque fichier local, mais les erreurs individuelles ne bloquent pas l’installation.
- Les liens vers des sites externes, ainsi que les PDF qui ne sont pas présents dans l’archive, ne peuvent pas être garantis hors connexion.
- Après chaque mise à jour publiée, changez CACHE_VERSION dans sw.js afin de forcer le renouvellement du cache.
- L’application doit être servie en HTTPS (GitHub Pages convient). L’ouverture directe d’index.html depuis le stockage du téléphone ne permet pas le service worker.
