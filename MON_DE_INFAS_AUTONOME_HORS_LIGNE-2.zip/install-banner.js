/* Bandeau « Installer l'application » : s'affiche en bas de l'écran sur téléphone.
   - Android / Chrome : un clic sur « Installer » ouvre directement la fenêtre d'installation.
   - iPhone / iPad : affiche les 2 gestes à faire (Partager > Sur l'écran d'accueil).
   - Disparaît si l'application est déjà installée ; la croix le masque 3 jours. */
(function(){
  'use strict';
  var KEY='infasInstallHide', JOURS=3;
  var ua=navigator.userAgent, ios=/iphone|ipad|ipod/i.test(ua), android=/android/i.test(ua);
  var standalone=(window.matchMedia&&matchMedia('(display-mode: standalone)').matches)||navigator.standalone;
  if(standalone)return;

  /* Rend le site installable sur toutes les pages */
  var head=document.head;
  if(!document.querySelector('link[rel="manifest"]')){var l=document.createElement('link');l.rel='manifest';l.href='manifest.json';head.appendChild(l)}
  if(!document.querySelector('link[rel="apple-touch-icon"]')){var a=document.createElement('link');a.rel='apple-touch-icon';a.href='apple-touch-icon.png';head.appendChild(a)}
  if('serviceWorker' in navigator&&/^https?:$/.test(location.protocol)){
    addEventListener('load',function(){navigator.serviceWorker.register('sw.js').catch(function(){})});
  }

  function masque(){try{var t=+localStorage.getItem(KEY)||0;return Date.now()-t<JOURS*864e5}catch(e){return false}}
  var ev=null, bar=null;
  addEventListener('beforeinstallprompt',function(e){e.preventDefault();ev=e;if(!bar)setTimeout(afficher,800)});
  addEventListener('appinstalled',function(){fermer(false)});

  function fermer(retenir){
    if(bar&&bar.parentNode)bar.parentNode.removeChild(bar);
    bar=null;
    if(retenir){try{localStorage.setItem(KEY,String(Date.now()))}catch(e){}}
  }

  function afficher(){
    if(bar||masque()||document.getElementById('infasInstallBar'))return;
    if(!ev&&!ios&&!android)return;               /* ordinateur sans possibilité d'installer : rien */
    var st=document.createElement('style');
    st.textContent='#infasInstallBar{position:fixed;left:10px;right:10px;bottom:calc(10px + env(safe-area-inset-bottom,0px));z-index:9999;background:#0b3d3a;color:#fff;border-radius:14px;padding:12px 14px;box-shadow:0 6px 24px rgba(0,0,0,.35);font:15px/1.35 system-ui,-apple-system,sans-serif;display:flex;align-items:center;gap:10px}'
      +'#infasInstallBar .ib-t{flex:1;min-width:0}#infasInstallBar b{display:block;font-size:15.5px}#infasInstallBar small{display:block;opacity:.85;font-size:13px}'
      +'#infasInstallBar button{border:0;font:inherit;cursor:pointer;border-radius:10px}'
      +'#infasInstallBar .ib-go{background:#1fd1c2;color:#06302d;font-weight:800;padding:10px 14px;white-space:nowrap}'
      +'#infasInstallBar .ib-x{background:none;color:#fff;opacity:.75;font-size:20px;padding:4px 8px}';
    document.head.appendChild(st);
    bar=document.createElement('div');bar.id='infasInstallBar';bar.setAttribute('role','dialog');bar.setAttribute('aria-label',"Installer l'application");
    bar.innerHTML='<div class="ib-t"><b>📲 Installez l\'application</b><small id="ibSub">Accès direct depuis votre écran d\'accueil, même sans connexion.</small></div>'
      +'<button class="ib-go" id="ibGo" type="button">Installer</button><button class="ib-x" id="ibX" type="button" aria-label="Fermer">✕</button>';
    document.body.appendChild(bar);
    var sub=document.getElementById('ibSub');
    document.getElementById('ibX').onclick=function(){fermer(true)};
    document.getElementById('ibGo').onclick=function(){
      if(ev){
        ev.prompt();
        (ev.userChoice||Promise.resolve()).then(function(){ev=null;fermer(false)},function(){ev=null});
      }else if(ios){
        sub.innerHTML='Touchez <b style="display:inline">Partager</b> (carré avec une flèche) puis <b style="display:inline">« Sur l\'écran d\'accueil »</b>.';
      }else{
        sub.innerHTML='Touchez le menu <b style="display:inline">⋮</b> du navigateur, puis <b style="display:inline">« Installer l\'application »</b> ou « Ajouter à l\'écran d\'accueil ».';
      }
    };
  }

  function planifier(){setTimeout(function(){if(!bar)afficher()},2500)}
  if(document.readyState==='complete')planifier();else addEventListener('load',planifier);
})();
