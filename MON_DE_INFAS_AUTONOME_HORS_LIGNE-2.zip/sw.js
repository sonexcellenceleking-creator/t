/* MON D.E INFAS — cache intégral des ressources locales pour la consultation hors connexion.
   Incrémentez CACHE_VERSION à chaque mise à jour publiée. */
const CACHE_VERSION = 'mon-de-infas-autonome-v1-wave7';
const PRECACHE = [
  "./manifest.json",
  "./sage-femme.html",
  "./data.js",
  "./schemas-illustrations.html",
  "./icon-192.png",
  "./jeu.js",
  "./sf.js",
  "./de.js",
  "./pf.js",
  "./generer-code.html",
  "./sw.js",
  "./script.js",
  "./classification-medicaments.html",
  "./cm.js",
  "./access.js",
  "./docs.js",
  "./apple-touch-icon.png",
  "./sante-publique.html",
  "./admin.html",
  "./LISEZ-MOI.txt",
  "./etudiants.jpg",
  "./data.enc.js",
  "./README.md",
  "./loader.js",
  "./sp.js",
  "./gl.js",
  "./cours-pdf.js",
  "./glossaire-medical.html",
  "./style.css",
  "./resume-pediatrie.html",
  "./prefixes-suffixes.html",
  "./accueil.jpg",
  "./sch.js",
  "./download",
  "./pwa.js",
  "./install-banner.js",
  "./cours.js",
  "./icon-512.png",
  "./salle-examen.jpg",
  "./index.html",
  "./pd.js",
  "./images/accueil.jpg",
  "./images/schemas/48.jpg",
  "./images/schemas/57.jpg",
  "./images/schemas/23.jpg",
  "./images/schemas/49.jpg",
  "./images/schemas/17.jpg",
  "./images/schemas/36.jpg",
  "./images/schemas/14.jpg",
  "./images/schemas/11.jpg",
  "./images/schemas/42.jpg",
  "./images/schemas/34.jpg",
  "./images/schemas/37.jpg",
  "./images/schemas/31.jpg",
  "./images/schemas/56.jpg",
  "./images/schemas/19.jpg",
  "./images/schemas/25.jpg",
  "./images/schemas/52.jpg",
  "./images/schemas/20.jpg",
  "./images/schemas/08.jpg",
  "./images/schemas/13.jpg",
  "./images/schemas/28.jpg",
  "./images/schemas/50.jpg",
  "./images/schemas/35.jpg",
  "./images/schemas/30.jpg",
  "./images/schemas/07.jpg",
  "./images/schemas/02.jpg",
  "./images/schemas/10.jpg",
  "./images/schemas/22.jpg",
  "./images/schemas/06.jpg",
  "./images/schemas/18.jpg",
  "./images/schemas/47.jpg",
  "./images/schemas/03.jpg",
  "./images/schemas/55.jpg",
  "./images/schemas/39.jpg",
  "./images/schemas/46.jpg",
  "./images/schemas/26.jpg",
  "./images/schemas/01.jpg",
  "./images/schemas/38.jpg",
  "./images/schemas/21.jpg",
  "./images/schemas/41.jpg",
  "./images/schemas/32.jpg",
  "./images/schemas/16.jpg",
  "./images/schemas/05.jpg",
  "./images/schemas/29.jpg",
  "./images/schemas/54.jpg",
  "./images/schemas/44.jpg",
  "./images/schemas/51.jpg",
  "./images/schemas/45.jpg",
  "./images/schemas/53.jpg",
  "./images/schemas/43.jpg",
  "./images/schemas/33.jpg",
  "./images/schemas/27.jpg",
  "./images/schemas/15.jpg",
  "./images/schemas/40.jpg",
  "./images/schemas/24.jpg",
  "./images/schemas/09.jpg",
  "./images/schemas/04.jpg",
  "./images/schemas/12.jpg",
  "./images/schemas/t/48.jpg",
  "./images/schemas/t/57.jpg",
  "./images/schemas/t/23.jpg",
  "./images/schemas/t/49.jpg",
  "./images/schemas/t/17.jpg",
  "./images/schemas/t/36.jpg",
  "./images/schemas/t/14.jpg",
  "./images/schemas/t/11.jpg",
  "./images/schemas/t/42.jpg",
  "./images/schemas/t/34.jpg",
  "./images/schemas/t/37.jpg",
  "./images/schemas/t/31.jpg",
  "./images/schemas/t/56.jpg",
  "./images/schemas/t/19.jpg",
  "./images/schemas/t/25.jpg",
  "./images/schemas/t/52.jpg",
  "./images/schemas/t/20.jpg",
  "./images/schemas/t/08.jpg",
  "./images/schemas/t/13.jpg",
  "./images/schemas/t/28.jpg",
  "./images/schemas/t/50.jpg",
  "./images/schemas/t/35.jpg",
  "./images/schemas/t/30.jpg",
  "./images/schemas/t/07.jpg",
  "./images/schemas/t/02.jpg",
  "./images/schemas/t/10.jpg",
  "./images/schemas/t/22.jpg",
  "./images/schemas/t/06.jpg",
  "./images/schemas/t/18.jpg",
  "./images/schemas/t/47.jpg",
  "./images/schemas/t/03.jpg",
  "./images/schemas/t/55.jpg",
  "./images/schemas/t/39.jpg",
  "./images/schemas/t/46.jpg",
  "./images/schemas/t/26.jpg",
  "./images/schemas/t/01.jpg",
  "./images/schemas/t/38.jpg",
  "./images/schemas/t/21.jpg",
  "./images/schemas/t/41.jpg",
  "./images/schemas/t/32.jpg",
  "./images/schemas/t/16.jpg",
  "./images/schemas/t/05.jpg",
  "./images/schemas/t/29.jpg",
  "./images/schemas/t/54.jpg",
  "./images/schemas/t/44.jpg",
  "./images/schemas/t/51.jpg",
  "./images/schemas/t/45.jpg",
  "./images/schemas/t/53.jpg",
  "./images/schemas/t/43.jpg",
  "./images/schemas/t/33.jpg",
  "./images/schemas/t/27.jpg",
  "./images/schemas/t/15.jpg",
  "./images/schemas/t/40.jpg",
  "./images/schemas/t/24.jpg",
  "./images/schemas/t/09.jpg",
  "./images/schemas/t/04.jpg",
  "./images/schemas/t/12.jpg",
  "./cours-pdf/LISEZ-MOI.txt",
  "./cours-pdf/pediatrie.pdf"
];

self.addEventListener('install', event => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_VERSION);
    // Chaque ressource est tentée individuellement : une ressource manquante ne bloque pas l'installation.
    await Promise.all(PRECACHE.map(async path => {
      try {
        const response = await fetch(path, { cache: 'reload' });
        if (response.ok) await cache.put(path, response);
      } catch (_) {}
    }));
    await self.skipWaiting();
  })());
});

self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter(key => key !== CACHE_VERSION).map(key => caches.delete(key)));
    await self.clients.claim();
  })());
});

// Le lecteur PDF peut demander des plages d'octets (Range). On les reconstruit depuis le PDF entier en cache.
self.addEventListener('fetch', event => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;

  event.respondWith((async () => {
    const cache = await caches.open(CACHE_VERSION);
    const cached = await cache.match(request, { ignoreSearch: false });
    if (request.headers.has('range') && /\\.pdf$/i.test(url.pathname)) {
      const full = cached || await cache.match(url.href) || await cache.match(new URL(url.pathname, self.location.origin).href);
      if (full) {
        const bytes = await full.arrayBuffer();
        const match = request.headers.get('range').match(/bytes=(\\d*)-(\\d*)/);
        if (match) {
          const start = match[1] ? Number(match[1]) : 0;
          const end = match[2] ? Math.min(Number(match[2]), bytes.byteLength - 1) : bytes.byteLength - 1;
          if (start <= end && start < bytes.byteLength) {
            return new Response(bytes.slice(start, end + 1), {
              status: 206,
              headers: {
                'Content-Type': 'application/pdf',
                'Content-Range': `bytes ${start}-${end}/${bytes.byteLength}`,
                'Content-Length': String(end - start + 1),
                'Accept-Ranges': 'bytes'
              }
            });
          }
        }
        return new Response(null, { status: 416, headers: { 'Content-Range': `bytes */${bytes.byteLength}` } });
      }
    }
    if (cached) return cached;
    try {
      const response = await fetch(request);
      if (response.ok && !request.headers.has('range')) {
        await cache.put(request, response.clone());
      }
      return response;
    } catch (_) {
      if (request.mode === 'navigate') {
        const home = await cache.match('./index.html');
        if (home) return home;
      }
      return new Response('Ressource indisponible hors connexion. Connectez-vous une fois pour la mettre en cache.', {
        status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' }
      });
    }
  })());
});
